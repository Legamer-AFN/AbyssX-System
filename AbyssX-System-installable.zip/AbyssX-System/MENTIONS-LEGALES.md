ABYSSX SYSTEM — LICENCE, MENTIONS LÉGALES ET CONFIDENTIALITÉ
Version 1.0 — octobre 2026

1. ÉDITEUR
AbyssX System est édité par AbyssX Community.
Contact : via la personne ou la page qui vous a transmis l'application.
Application gratuite, fournie en l'état. Elle fonctionne entièrement sur votre ordinateur : aucun serveur, aucun hébergement de vos données.

2. LICENCE D'UTILISATION (LICENCE MIT)
Copyright (c) 2026 AbyssX Community

Traduction de courtoisie en français. En cas de différence, le texte anglais d'origine (reproduit à la fin de ce document) fait foi pour l'interprétation de la licence.

Il est accordé gratuitement à toute personne obtenant une copie de ce logiciel et des fichiers de documentation associés (le « Logiciel ») le droit d'utiliser le Logiciel sans restriction, y compris, sans limitation, les droits d'utiliser, copier, modifier, fusionner, publier, distribuer, concéder en sous-licence et/ou vendre des copies du Logiciel, et de permettre aux personnes à qui le Logiciel est fourni de le faire, sous réserve des conditions suivantes :

L'avis de copyright ci-dessus et le présent avis d'autorisation doivent être inclus dans toutes les copies ou parties substantielles du Logiciel.

LE LOGICIEL EST FOURNI « TEL QUEL », SANS GARANTIE D'AUCUNE SORTE, EXPRESSE OU IMPLICITE, Y COMPRIS, SANS LIMITATION, LES GARANTIES DE QUALITÉ MARCHANDE, D'ADÉQUATION À UN USAGE PARTICULIER ET D'ABSENCE DE CONTREFAÇON. EN AUCUN CAS LES AUTEURS OU TITULAIRES DU COPYRIGHT NE POURRONT ÊTRE TENUS RESPONSABLES DE TOUTE RÉCLAMATION, DE TOUT DOMMAGE OU DE TOUTE AUTRE RESPONSABILITÉ, DANS LE CADRE D'UNE ACTION CONTRACTUELLE, DÉLICTUELLE OU AUTRE, RÉSULTANT DU LOGICIEL, DE SON UTILISATION OU D'AUTRES OPÉRATIONS DANS LE LOGICIEL.

Aucune disposition de la présente licence ne limite les droits que la loi française reconnaît de manière impérative à l'utilisateur, notamment en tant que consommateur. La présente licence est régie par le droit français.

3. DONNÉES PERSONNELLES ET COOKIES (RGPD, loi Informatique et Libertés)
• L'application lit localement des informations techniques de votre ordinateur (processeur, carte mère, mémoire, carte graphique, disques, écrans, périphériques, processus en cours, nom de l'ordinateur ; les numéros de série et adresses MAC ne sont pas lus) uniquement pour les afficher dans sa fenêtre.
• Aucune donnée n'est transmise, ni à l'éditeur ni à un tiers : l'application n'effectue aucune connexion réseau et ne charge aucune ressource externe. Il n'y a ni compte, ni télémétrie, ni publicité.
• L'éditeur n'a accès à aucune de vos données personnelles et ne réalise aucun traitement de données personnelles à votre sujet.
• L'application n'utilise aucun cookie ni traceur : aucun consentement n'est donc requis.
• Fichiers créés sur votre ordinateur, dans le dossier « AbyssX System » de %APPDATA% : un fichier mémorisant votre acceptation de cette licence (strictement nécessaire au fonctionnement) et un journal technique d'erreurs, qui n'est jamais envoyé. Vous pouvez les supprimer à tout moment.
• Le rapport de diagnostic que vous choisissez d'exporter contient le nom de votre ordinateur : vous décidez seul(e) de le partager ou non.
• Vous pouvez adresser une réclamation à la CNIL (www.cnil.fr).

4. COMPOSANTS TIERS
• Electron, © OpenJS Foundation et contributeurs d'Electron (licence MIT), et Chromium (licences BSD et autres) : leurs textes complets sont fournis dans les fichiers LICENSE.electron.txt et LICENSES.chromium.html, à côté de l'application.
• systeminformation, © Sebastian Hildebrandt (licence MIT).
• Les polices utilisées sont celles de votre système.

5. LANGUE
L'interface et la documentation de l'application sont en français.

6. TEXTE ORIGINAL DE LA LICENCE (ENGLISH — MIT LICENSE)
Copyright (c) 2026 AbyssX Community

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
