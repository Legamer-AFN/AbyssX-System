@echo off
chcp 65001 >nul
title AbyssX System - Test
cd /d "%~dp0"
where node >nul 2>nul || ( echo Node.js manquant : https://nodejs.org/ & pause & exit /b 1 )
if not exist node_modules ( call npm install )
call npm start
pause
