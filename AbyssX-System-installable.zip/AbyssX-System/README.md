# AbyssX System

Tableau de bord PC (Electron, Windows). Une fois installée, c'est une vraie application : raccourci sur le Bureau et dans le menu Démarrer, lancement d'un double-clic, et elle marche toujours après un redémarrage du PC. Aucune commande, aucun `.bat` pour l'utiliser.

## 1. Obtenir l'installateur (une seule fois)

Choisis UNE des deux méthodes.

**A. Sur ton PC** (Node.js LTS requis : https://nodejs.org/)

1. Double-clique sur `1-CREER-LE-EXE.bat` (internet requis, quelques minutes).
2. L'installateur est dans le dossier `release` : `AbyssX-System-Setup.exe`.

**B. Sans rien installer sur ton PC** (GitHub, gratuit)

1. Crée un compte sur https://github.com puis un dépôt (bouton « New »).
2. Clique sur « uploading an existing file », glisse tout le contenu du dossier `AbyssX-System` (pas le .zip), puis « Commit changes ». Si le dossier `.github` n'apparaît pas : « Add file » > « Create new file », nom `.github/workflows/build.yml`, colle le contenu du fichier du même nom.
3. Onglet « Actions » : attends la coche verte (environ 5 minutes), ouvre l'exécution, puis télécharge `AbyssX-System-Installateur` en bas de page (un .zip qui contient `AbyssX-System-Setup.exe`).
4. Pour envoyer un lien à tes amis : « Releases » > « Draft a new release », crée un tag (ex. `v1.0.0`), « Publish release ». L'installateur s'ajoute tout seul à la release au bout de quelques minutes.

## 2. Installer

Double-clique sur `AbyssX-System-Setup.exe`. L'installation se fait en une étape, sans droits administrateur, dans ton profil Windows : raccourcis Bureau et menu Démarrer, puis l'appli s'ouvre. Tes amis font pareil (ils n'ont pas besoin de Node.js).

Pour désinstaller : Paramètres Windows > Applications.

Pour tester sans créer l'installateur : `2-TESTER-SANS-EXE.bat`.

## Légal (France)

- Tout est dans `MENTIONS-LEGALES.md` (copié dans le dossier d'installation) et affiché dans l'appli : licence MIT avec traduction française, mentions, RGPD, cookies, composants tiers.
- Au premier lancement, chaque utilisateur doit accepter la licence ; son choix est mémorisé sur son PC. Elle reste consultable dans Paramètres > Licence et mentions légales.
- Aucun cookie, aucune donnée envoyée : aucun bandeau cookies n'est nécessaire.
- Pour mettre ton nom ou ton contact : modifie `src/legal-info.json` (et `LICENSE`, `MENTIONS-LEGALES.md`), puis recrée l'installateur.
- Si tu vends l'appli ou la diffuses sur un site, d'autres obligations s'ajoutent (identité de l'éditeur, conditions de vente, etc.).

## Notes

- L'installateur n'est pas signé numériquement : Windows peut afficher « Windows a protégé votre ordinateur » → « Informations complémentaires » → « Exécuter quand même ». Seul un certificat de signature de code payant supprime cet avertissement.
- Les températures et le GPU dépendent des capteurs et pilotes de la machine.
- Quand la fenêtre est réduite, l'appli arrête ses lectures pour ne pas solliciter le PC ; elles reprennent à la réouverture.
