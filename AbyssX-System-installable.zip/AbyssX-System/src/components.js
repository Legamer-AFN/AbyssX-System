// Inventaire du matériel (lecture locale uniquement). Numéros de série et adresses MAC volontairement ignorés.
const JUNK = /^(to be filled by o\.e\.m\.?|default string|system product name|system manufacturer|not applicable|n\/a|unknown|none|0)$/i;
const clean = v => { const s = String(v ?? '').trim(); return JUNK.test(s) ? '' : s; };
const bin = b => { const n = Number(b) || 0; if (!n) return ''; if (n < 1048576) return Math.round(n / 1024) + ' Ko'; const go = n / 1073741824; return go < 1 ? Math.round(n / 1048576) + ' Mo' : (go >= 10 ? Math.round(go) : go.toFixed(1)) + ' Go'; };
const dec = b => { const n = Number(b) || 0; if (!n) return ''; const go = n / 1e9; return go >= 1000 ? (go / 1000).toFixed(go >= 10000 ? 0 : 1) + ' To' : Math.round(go) + ' Go'; };
const rows = list => list.map(([l, v]) => [l, clean(v)]).filter(([, v]) => v);
const block = (title, list) => ({ title, rows: rows(list) });
const group = (title, icon, blocks) => ({ title, icon, blocks: blocks.filter(b => b.rows.length) });

async function buildComponents(si) {
  const safe = (p, f) => Promise.resolve(p).catch(() => f);
  const [sys, bios, board, chassis, cpu, memL, gfx, disks, net, bat, audio, usb, osI, mem] = await Promise.all([
    safe(si.system(), {}), safe(si.bios(), {}), safe(si.baseboard(), {}), safe(si.chassis(), {}), safe(si.cpu(), {}),
    safe(si.memLayout(), []), safe(si.graphics(), { controllers: [], displays: [] }), safe(si.diskLayout(), []),
    safe(si.networkInterfaces(), []), safe(si.battery(), {}), safe(si.audio(), []), safe(si.usb(), []),
    safe(si.osInfo(), {}), safe(si.mem(), {})
  ]);
  const arr = x => (Array.isArray(x) ? x : x ? [x] : []);
  const groups = [];

  groups.push(group('Système', '🖥', [block('', [
    ['Fabricant', sys.manufacturer], ['Modèle', sys.model], ['Type de châssis', chassis.type],
    ['Machine virtuelle', sys.virtual ? 'Oui' : ''], ['Système', osI.distro], ['Version', osI.release],
    ['Build', osI.build], ['Architecture', osI.arch]])]));

  groups.push(group('Carte mère et BIOS', '▦', [block('', [
    ['Fabricant', board.manufacturer], ['Modèle', board.model], ['Version', board.version],
    ['Emplacements mémoire', board.memSlots], ['Mémoire maximale', bin(board.memMax)],
    ['BIOS', bios.vendor], ['Version du BIOS', bios.version], ['Date du BIOS', bios.releaseDate]])]));

  const c = cpu.cache || {};
  groups.push(group('Processeur', '⚙', [block('', [
    ['Modèle', [cpu.manufacturer, cpu.brand].filter(Boolean).join(' ')],
    ['Cœurs physiques', cpu.physicalCores], ['Threads', cpu.cores],
    ['Fréquence de base', cpu.speed ? cpu.speed + ' GHz' : ''], ['Fréquence maximale', cpu.speedMax ? cpu.speedMax + ' GHz' : ''],
    ['Socket', cpu.socket], ['Virtualisation', typeof cpu.virtualization === 'boolean' ? (cpu.virtualization ? 'Activée' : 'Désactivée') : ''],
    ['Cache L1 données', bin(c.l1d)], ['Cache L1 instructions', bin(c.l1i)], ['Cache L2', bin(c.l2)], ['Cache L3', bin(c.l3)]])]));

  const modules = arr(memL);
  groups.push(group('Mémoire vive', '▤', [
    block('', [['Total', bin(mem.total)], ['Barrettes détectées', modules.length || '']]),
    ...modules.map((m, i) => block('Barrette ' + (i + 1), [
      ['Capacité', bin(m.size)], ['Type', m.type], ['Vitesse', m.clockSpeed ? m.clockSpeed + ' MHz' : ''],
      ['Fabricant', m.manufacturer], ['Référence', m.partNum], ['Emplacement', m.bank]]))]));

  groups.push(group('Cartes graphiques et écrans', '◈', [
    ...arr(gfx.controllers).map((g, i) => block('Carte graphique ' + (i + 1), [
      ['Modèle', g.model], ['Fabricant', g.vendor], ['Mémoire vidéo', g.vram ? bin(g.vram * 1048576) : ''], ['Bus', g.bus]])),
    ...arr(gfx.displays).map((d, i) => block('Écran ' + (i + 1), [
      ['Modèle', d.model || d.deviceName], ['Résolution', (d.currentResX || d.resolutionX) ? `${d.currentResX || d.resolutionX} × ${d.currentResY || d.resolutionY}` : ''],
      ['Fréquence', d.currentRefreshRate ? d.currentRefreshRate + ' Hz' : ''], ['Principal', d.main ? 'Oui' : '']]))]));

  groups.push(group('Stockage', '▥', arr(disks).map((d, i) => block('Disque ' + (i + 1), [
    ['Nom', d.name], ['Type', d.type], ['Interface', d.interfaceType], ['Capacité', dec(d.size)],
    ['Fabricant', d.vendor], ['Firmware', d.firmwareRevision]]))));

  const ifaces = arr(net).filter(n => n && !n.internal).sort((a, b) => Number(!!a.virtual) - Number(!!b.virtual)).slice(0, 6);
  const typeFr = { wired: 'Filaire', wireless: 'Wi-Fi' };
  groups.push(group('Réseau', '⌁', ifaces.map(n => block(n.ifaceName || n.iface || 'Interface', [
    ['Type', typeFr[n.type] || n.type], ['Vitesse', n.speed > 0 ? n.speed + ' Mbit/s' : ''],
    ['État', n.operstate === 'up' ? 'Connecté' : n.operstate === 'down' ? 'Déconnecté' : n.operstate],
    ['Adaptateur virtuel', n.virtual ? 'Oui' : '']]))));

  groups.push(group('Batterie', '🔋', [block('', bat && bat.hasBattery ? [
    ['Charge', bat.percent != null ? bat.percent + ' %' : ''], ['État', bat.isCharging ? 'En charge' : bat.acConnected ? 'Branchée' : 'Sur batterie'],
    ['Cycles de charge', bat.cycleCount], ['Capacité maximale', bat.maxCapacity ? `${bat.maxCapacity} ${bat.capacityUnit || 'mWh'}` : ''],
    ['Capacité d\'origine', bat.designedCapacity ? `${bat.designedCapacity} ${bat.capacityUnit || 'mWh'}` : '']
  ] : [['Batterie', 'Aucune détectée (PC fixe)']])]));

  const seen = new Set();
  const aud = arr(audio).filter(a => a && a.name && !seen.has(a.name) && seen.add(a.name)).slice(0, 6);
  groups.push(group('Audio', '♪', [block('', aud.map(a => [a.name, a.manufacturer || (a.in && a.out ? 'Entrée / sortie' : a.out ? 'Sortie' : a.in ? 'Entrée' : '')]))]));

  const seenU = new Set();
  const usbs = arr(usb).filter(u => u && u.name && !/hub/i.test(u.name + ' ' + (u.type || '')) && !seenU.has(u.name) && seenU.add(u.name)).slice(0, 10);
  groups.push(group('Périphériques USB', '⏏', [block('', usbs.map(u => [u.name, u.manufacturer || u.type || '']))]));

  return { groups: groups.filter(g => g.blocks.length), at: new Date().toISOString() };
}

module.exports = { buildComponents };
