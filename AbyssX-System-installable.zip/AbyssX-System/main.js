const { app, BrowserWindow, Menu, ipcMain } = require('electron');
const path = require('node:path');
const os = require('node:os');
const fs = require('node:fs');
const si = require('systeminformation');
const { buildComponents } = require('./src/components.js');

app.setName('AbyssX System');
if (process.platform === 'win32') app.setAppUserModelId('com.abyssx.system');
// Une seule fenêtre à la fois : une 2e instance se ferme sans rien afficher
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) app.quit();

// Journal d'erreurs local (jamais envoyé) : une erreur imprévue ne fait plus planter l'appli
function logError(label, err) {
  try {
    const file = path.join(app.getPath('userData'), 'error.log');
    fs.mkdirSync(path.dirname(file), { recursive: true });
    try { if (fs.statSync(file).size > 200000) fs.truncateSync(file, 0); } catch {}
    fs.appendFileSync(file, `[${new Date().toISOString()}] ${label}: ${(err && err.stack) || err}\n`);
  } catch {}
}
process.on('uncaughtException', e => logError('uncaughtException', e));
process.on('unhandledRejection', e => logError('unhandledRejection', e));

let mainWindow = null;
let reloads = [];

function createWindow() {
  Menu.setApplicationMenu(null); // pas de menu par défaut « Electron » (touche Alt) ni de raccourcis développeur
  mainWindow = new BrowserWindow({
    width: 1440, height: 900, minWidth: 1080, minHeight: 700,
    backgroundColor: '#06090f', title: 'AbyssX System',
    icon: path.join(__dirname, 'src', 'logo.png'),
    autoHideMenuBar: true, show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true, nodeIntegration: false, sandbox: true
    }
  });
  mainWindow.once('ready-to-show', () => mainWindow.show());
  // Filet de sécurité : si « ready-to-show » n'arrive jamais, la fenêtre s'affiche quand même (plus de processus invisible)
  setTimeout(() => { if (mainWindow && !mainWindow.isVisible()) mainWindow.show(); }, 5000);
  mainWindow.on('closed', () => { mainWindow = null; });
  mainWindow.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  mainWindow.webContents.on('will-navigate', e => e.preventDefault());
  mainWindow.webContents.on('did-fail-load', (_e, code, desc) => logError('did-fail-load', `${code} ${desc}`));
  // Si la page plante, on la recharge (3 fois par minute au maximum) au lieu de laisser une fenêtre blanche
  mainWindow.webContents.on('render-process-gone', (_e, d) => {
    logError('render-process-gone', d && d.reason);
    const now = Date.now();
    reloads = reloads.filter(t => now - t < 60000);
    if (mainWindow && d && d.reason !== 'clean-exit' && reloads.length < 3) { reloads.push(now); mainWindow.reload(); }
  });
  mainWindow.loadFile('index.html');
}

app.on('second-instance', () => {
  if (mainWindow) { if (mainWindow.isMinimized()) mainWindow.restore(); mainWindow.focus(); }
});

// Cache en arrière-plan : la fenêtre n'attend jamais une lecture lente.
// emptyTtl : délai avant de réessayer quand la lecture ne renvoie rien (ex. aucun capteur de température)
function cached(loader, ttl, emptyTtl = ttl) {
  let value, at = -Infinity, busy = false;
  return () => {
    if (!busy && Date.now() - at >= ttl) {
      busy = true;
      loader()
        .then(v => { value = v; at = Date.now() + (v == null ? emptyTtl - ttl : 0); })
        .catch(e => { logError('lecture système', e); at = Date.now() - ttl + 30000; })
        .finally(() => { busy = false; });
    }
    return value;
  };
}

const getStatic = cached(async () => {
  const [osInfo, cpu, graphics, layout, network] = await Promise.all([
    si.osInfo().catch(() => ({})), si.cpu().catch(() => ({})), si.graphics().catch(() => ({ controllers: [] })),
    si.diskLayout().catch(() => []), si.networkInterfaces().catch(() => [])
  ]);
  return {
    platform: osInfo.distro || osInfo.platform || process.platform,
    release: osInfo.release || os.release(),
    cpuName: [cpu.manufacturer, cpu.brand].filter(Boolean).join(' ') || 'Processeur inconnu',
    cpuCores: cpu.cores || os.cpus().length,
    gpus: (graphics.controllers || []).map(g => ({ model: g.model || 'GPU', vendor: g.vendor || '', vram: g.vram || null })),
    diskLayout: (layout || []).map(d => ({ name: d.name || d.vendor || 'Stockage', type: d.type || 'Disque', size: d.size || 0 })),
    network: (Array.isArray(network) ? network : [network]).filter(n => n && !n.internal)
      .map(n => ({ name: n.ifaceName || n.iface || 'Réseau', speed: n.speed || 0, type: n.type || '' })).slice(0, 4)
  };
}, 1e12);

const getDisks = cached(async () => (await si.fsSize()).map(d => ({
  mount: d.mount || d.fs || 'Disque', size: d.size || 0, used: d.used || 0, use: d.use || 0 })), 15000);
const getTemp = cached(async () => (await si.cpuTemperature()).main ?? null, 5000, 60000);
const getProcesses = cached(async () => ((await si.processes()).list || [])
  .sort((a, b) => (b.mem || 0) - (a.mem || 0)).slice(0, 8)
  .map(p => ({ name: p.name || p.command || 'Processus', cpu: Number(p.cpu || 0), memory: Number(p.mem || 0) })), 5000);

let inFlight = null;
async function takeSnapshot() {
  const [load, mem] = await Promise.all([
    si.currentLoad().catch(() => ({ currentLoad: 0 })),
    si.mem().catch(() => ({ total: os.totalmem(), available: os.freemem() }))
  ]);
  const st = getStatic() || {};
  const ramUsed = Math.max(0, mem.total - mem.available); // même base pour les Go affichés et le pourcentage
  return {
    ok: true, platform: st.platform || process.platform, release: st.release || os.release(),
    hostname: os.hostname(), arch: os.arch(), uptime: os.uptime(),
    cpuName: st.cpuName || 'Détection…', cpuCores: st.cpuCores || os.cpus().length,
    cpuLoad: Math.round(load.currentLoad || 0),
    ramTotal: mem.total, ramUsed, ramFree: mem.available,
    ramPercent: Math.round((ramUsed / Math.max(1, mem.total)) * 100),
    temperature: getTemp() ?? null, gpus: st.gpus || [], disks: getDisks() || [],
    diskLayout: st.diskLayout || [], network: st.network || [], processes: getProcesses() || [],
    sampledAt: new Date().toISOString()
  };
}

ipcMain.handle('system:snapshot', async () => {
  try {
    if (!inFlight) inFlight = takeSnapshot().finally(() => { inFlight = null; });
    return await inFlight;
  } catch (error) {
    logError('snapshot', error);
    return { ok: false, error: String((error && error.message) || error) };
  }
});

// ---- Inventaire des composants : lu à l'ouverture de la page, puis gardé en cache (« Réanalyser » le relit) ----
let compPromise = null;
ipcMain.handle('system:components', async (_e, force) => {
  try {
    if (force || !compPromise) {
      compPromise = buildComponents(si);
      compPromise.catch(() => { compPromise = null; });
    }
    return { ok: true, data: await compPromise };
  } catch (error) {
    logError('composants', error);
    compPromise = null;
    return { ok: false, error: String((error && error.message) || error) };
  }
});

// ---- Licence et mentions légales (texte en français, éditeur réglable dans src/legal-info.json) ----
const LICENSE_VERSION = '2';
const licenseFile = () => path.join(app.getPath('userData'), 'license.json');
function legalText() {
  let tpl = '', info = {};
  try { tpl = fs.readFileSync(path.join(__dirname, 'src', 'legal-template.txt'), 'utf8'); } catch (e) { logError('legal-template', e); }
  try { info = JSON.parse(fs.readFileSync(path.join(__dirname, 'src', 'legal-info.json'), 'utf8')); } catch {}
  return tpl.replace(/\{\{editeur\}\}/g, info.editeur || 'AbyssX Community')
            .replace(/\{\{contact\}\}/g, info.contact || 'via la personne qui vous a transmis l\'application');
}
ipcMain.handle('license:get', () => {
  let accepted = false;
  try { accepted = JSON.parse(fs.readFileSync(licenseFile(), 'utf8')).version === LICENSE_VERSION; } catch {}
  return { accepted, text: legalText() };
});
ipcMain.handle('license:accept', () => {
  try {
    fs.mkdirSync(app.getPath('userData'), { recursive: true });
    fs.writeFileSync(licenseFile(), JSON.stringify({ version: LICENSE_VERSION, at: new Date().toISOString() }));
    return true;
  } catch (e) { logError('license', e); return false; }
});
ipcMain.handle('license:decline', () => { app.quit(); });

app.whenReady().then(() => {
  if (!gotLock) return;
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
