const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('abyssx', {
  getSnapshot: () => ipcRenderer.invoke('system:snapshot'),
  getComponents: force => ipcRenderer.invoke('system:components', !!force),
  getLicense: () => ipcRenderer.invoke('license:get'),
  acceptLicense: () => ipcRenderer.invoke('license:accept'),
  declineLicense: () => ipcRenderer.invoke('license:decline')
});
