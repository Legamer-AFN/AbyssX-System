@echo off
chcp 65001 >nul
title AbyssX System - Creation de l'installateur
cd /d "%~dp0"
set CSC_IDENTITY_AUTO_DISCOVERY=false

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Node.js n'est pas installe. Installe la version LTS ici :
  echo  https://nodejs.org/
  echo  Puis relance ce fichier.
  start https://nodejs.org/
  pause
  exit /b 1
)

echo.
echo  [1/3] Installation des composants (internet requis, quelques minutes)...
call npm install
if errorlevel 1 ( echo. & echo  ERREUR pendant npm install. & pause & exit /b 1 )

echo.
echo  [2/3] Creation de l'installateur (ferme AbyssX System s'il est ouvert)...
if exist release rmdir /s /q release
call npm run dist
if errorlevel 1 (
  echo.
  echo  Nouvel essai sans la methode standard de personnalisation du .exe...
  if exist release rmdir /s /q release
  call npx electron-builder --win --publish never -c.win.signAndEditExecutable=false
  if errorlevel 1 ( echo. & echo  ERREUR pendant la creation de l'installateur. & pause & exit /b 1 )
)
if not exist "release\AbyssX-System-Setup.exe" ( echo. & echo  ERREUR : release\AbyssX-System-Setup.exe est introuvable. & pause & exit /b 1 )

echo.
echo  [3/3] Verification du nom affiche (clic droit ^> Proprietes ^> Details) :
powershell -NoProfile -Command "Get-ChildItem 'release\AbyssX-System-Setup.exe','release\win-unpacked\AbyssX System.exe' -ErrorAction SilentlyContinue | ForEach-Object { Write-Host ('--- ' + $_.Name); Write-Host ('Produit     : ' + $_.VersionInfo.ProductName); Write-Host ('Description : ' + $_.VersionInfo.FileDescription); Write-Host ('Societe     : ' + $_.VersionInfo.CompanyName) }"

echo.
echo  TERMINE. Ton installateur est ici :
echo    release\AbyssX-System-Setup.exe
echo.
echo  Double-clique dessus : l'appli s'installe toute seule (raccourci Bureau + menu Demarrer).
echo  Ensuite plus aucune commande ni .bat : elle se lance comme n'importe quel programme, meme apres un redemarrage.
echo  Tu peux envoyer ce seul fichier a tes amis : ils n'ont pas besoin de Node.js.
start "" "%~dp0release"
pause
